//
//  CCCirculationModel.h
//  西邮图书馆
//
//  Created by 满脸胡茬的怪蜀黍 on 2017/2/18.
//  Copyright © 2017年 陈普钦. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CCCirculationModel : NSObject
@property(strong,nonatomic)NSString *Barcode;
@property(strong,nonatomic)NSString *Date;
@property(strong,nonatomic)NSString *Department;
@property(strong,nonatomic)NSString *Sort;
@property(strong,nonatomic)NSString *Status;
@end
