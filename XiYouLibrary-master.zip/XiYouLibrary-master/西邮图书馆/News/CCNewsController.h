//
//  CCNewsController.h
//  
//
//  Created by 陈普钦 on 16/11/14.
//
//

#import <UIKit/UIKit.h>

@interface CCNewsController : UIViewController

@end
