//
//  CCSystemController.h
//  
//
//  Created by 陈普钦 on 16/11/14.
//
//

#import <UIKit/UIKit.h>

@interface CCSystemController : UIViewController
@property(assign,nonatomic)BOOL isLogin;
@end
