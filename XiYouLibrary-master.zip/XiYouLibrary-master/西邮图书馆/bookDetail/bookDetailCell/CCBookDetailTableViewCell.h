//
//  CCBookDetailTableViewCell.h
//  西邮图书馆
//
//  Created by 满脸胡茬的怪蜀黍 on 2017/2/17.
//  Copyright © 2017年 陈普钦. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CCBookDetailTableViewCell : UITableViewCell
@property(strong,nonatomic)UILabel *authorLabel;
@property(strong,nonatomic)UILabel *sortLabel;
@property(strong,nonatomic)UILabel *pubLabel;
@property(strong,nonatomic)UILabel *favLabel;
@property(strong,nonatomic)UILabel *renttimesLabel;
@end
