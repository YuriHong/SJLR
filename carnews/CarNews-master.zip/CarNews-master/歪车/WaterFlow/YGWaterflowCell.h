//
//  YGWaterflowCell.h
//  瀑布流
//
//  Created by qianfeng on 15/10/15.
//  Copyright (c) 2015年 YG. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YGWaterflowCell : UIView
@property (nonatomic,copy) NSString *identifier;
@end
