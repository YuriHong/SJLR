//
//  YGMainController.h
//  leftView
//



#import <UIKit/UIKit.h>

@interface ZCMainController : UIViewController

@end
