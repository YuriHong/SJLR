//
//  YGHaocheFirModel.h
//  歪车
//


#import <Foundation/Foundation.h>

@interface ZCHaocheFirModel : NSObject
@property (nonatomic,copy) NSString *title;
@property (nonatomic,copy) NSString *long_brief;
@property (nonatomic,copy) NSString *brief;
@property (nonatomic,copy) NSString *pic;
@property (nonatomic,copy) NSString *url;
@end
