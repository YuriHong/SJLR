//
//  YGLeftVIewButton.m
//  leftView
//


#import "ZCLeftVIewButton.h"
//按钮设置高亮
@implementation ZCLeftVIewButton
- (void)setHighlighted:(BOOL)highlighted
{
    
}
@end
