//
//  YGLeftVIewButton.h
//  leftView
//



#import <UIKit/UIKit.h>

@interface ZCLeftVIewButton : UIButton

@end
