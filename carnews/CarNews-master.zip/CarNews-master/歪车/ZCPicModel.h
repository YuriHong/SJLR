//
//  YGPicModel.h
//  歪车
//


#import <Foundation/Foundation.h>

@interface ZCPicModel : NSObject
@property (nonatomic,copy) NSString *list_cover;
@end
