//
//  YGAdsModel.h
//  歪车
//


#import <Foundation/Foundation.h>

@interface ZCAdsModel : NSObject
@property (nonatomic,copy) NSString *title;
@property (nonatomic,copy) NSString *pic;
@property (nonatomic,copy) NSString *url;
@end
