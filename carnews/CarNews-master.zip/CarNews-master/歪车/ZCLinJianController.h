//
//  YGLinJianController.h
//  歪车
//


#import <UIKit/UIKit.h>
@class ZCItemModel;
@interface ZCLinJianController : UIViewController
@property (nonatomic,strong) ZCItemModel *itemmodel;
@end
