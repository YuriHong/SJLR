//
//  YGHaoDetailController.h
//  歪车
//



#import <UIKit/UIKit.h>
@class ZCHaocheFirModel;
@interface ZCHaoDetailController : UIViewController
@property (nonatomic,strong) ZCHaocheFirModel *model;
@property (nonatomic,copy) NSString *adsUrl;
@property (nonatomic,copy) NSString *pic;
@end
