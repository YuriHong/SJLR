//
//  YGWarPicController.h
//  歪车
//


#import <UIKit/UIKit.h>

@interface ZCWarPicController : UIViewController
@property (nonatomic,strong) NSArray *array;
@end
