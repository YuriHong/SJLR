//
//  YGDetailController.h
//  歪车
//


#import <UIKit/UIKit.h>
@class ZCNiuCheModel;
@interface ZCDetailController : UIViewController
@property (nonatomic,strong) ZCNiuCheModel *model;
@end
