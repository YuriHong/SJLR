//
//  YGCoverView.h
//  歪车
//


#import <UIKit/UIKit.h>

@interface ZCCoverView : UIView
@property (nonatomic,copy) NSString  *carID;
@end
