//
//  YGNavgationController.h
//  leftView
//


#import <UIKit/UIKit.h>

@interface ZCNavgationController : UINavigationController

@end
