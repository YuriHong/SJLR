//
//  YGPicListModel.h
//  歪车
//


#import <Foundation/Foundation.h>

@interface ZCPicListModel : NSObject
@property (nonatomic,copy) NSArray *list;
@end
