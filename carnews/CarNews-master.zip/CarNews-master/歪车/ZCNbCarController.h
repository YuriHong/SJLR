//
//  YGNbCarController.h
//  歪车
//


#import <UIKit/UIKit.h>

@interface ZCNbCarController : UITableViewController

@end
