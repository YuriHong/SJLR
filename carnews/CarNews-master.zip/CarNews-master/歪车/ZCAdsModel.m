//
//  YGAdsModel.m
//  歪车
//


#import "ZCAdsModel.h"

@implementation ZCAdsModel

@end
