//
//  YGHaocheFirModel.m
//  歪车
//

#import "ZCHaocheFirModel.h"

@implementation ZCHaocheFirModel

@end
